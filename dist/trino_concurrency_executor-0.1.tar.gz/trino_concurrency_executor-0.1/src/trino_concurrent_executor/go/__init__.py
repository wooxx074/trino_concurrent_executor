from .py_build.trino_concurrent_executor import hello_world

__all__ = (
    "hello_world",
)

def test():
    print('testing')