from trino_concurrency_executor import go

def main() -> None:
    print(go.hello_world())
