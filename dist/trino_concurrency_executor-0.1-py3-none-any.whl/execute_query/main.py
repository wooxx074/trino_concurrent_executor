from trino_concurrent_executor import go

def main() -> None:
    print(go.hello_world())
